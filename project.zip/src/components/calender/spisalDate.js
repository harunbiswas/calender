const specialDate = {
  cheap: [4, 5, 6, 10, 11, 15, 16, 18, 19],
  medium: [7, 8, 9, 12, 13, 14, 28, 29],
  expensive: [1, 2, 3, 17, 20, 21, 22],
};

export default specialDate;
