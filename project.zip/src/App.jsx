import "./App.scss";
import Calender from "./components/Calender";

function App() {
  return (
    <>
      <div className="">
        <Calender />
      </div>
    </>
  );
}

export default App;
